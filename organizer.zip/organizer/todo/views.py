from django.shortcuts import render,redirect
from .models import Task
from .forms import TaskForm

# Create your views here.

def index(request):
    task_list= Task.objects.order_by('date_created')

    if request.method == "POST":
        data = request.POST #gives us a dictionary
        task_form = TaskForm(data)

        if task_form.is_valid(): 
            #checks the specification and if it's valid it saves it.
            #we can then redirect or do sth else when it's satisfied
            task_form.save()
            redirect('tasks')
    
    task_form = TaskForm()
    context = {
        "form": task_form,
        "tasks": task_list
    }

    return render(request,"todo/index.html",context)